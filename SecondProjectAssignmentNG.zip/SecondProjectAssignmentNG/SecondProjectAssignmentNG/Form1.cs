﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SecondProjectAssignmentNG
{
    public partial class Form1 : Form
    {
        String font = "Times New Roman"; // default font
        FontStyle format = FontStyle.Regular; // default format
        List<ClipEntry> clipboard = new List<ClipEntry>(); // storing the clipboard itself as a backing list so it sorts much easier
        int size = 9; // default size

        

        public Form1()
        {
            InitializeComponent();
        }
        private void UpdateFont() // helper for changing the font in the textbox
        {
            TextEnter.Font = new Font(font, size, format);
        }

        // radio buttons
        private void FontOne_CheckedChanged(object sender, EventArgs e)
        {
            font = "Times New Roman";
            UpdateFont();
        }

        private void FontTwo_CheckedChanged(object sender, EventArgs e)
        {
            font = "Poor Richard";
            UpdateFont();
        }

        private void FontThree_CheckedChanged(object sender, EventArgs e)
        {
            font = "Jokerman";
            UpdateFont();
        }

        private void FontFour_CheckedChanged(object sender, EventArgs e)
        {
            font = "Algerian";
            UpdateFont();
        }

        private void FormatOne_CheckedChanged(object sender, EventArgs e)
        {
            format = FontStyle.Regular;
            UpdateFont();
        }

        private void FormatTwo_CheckedChanged(object sender, EventArgs e)
        {
            format = FontStyle.Italic;
            UpdateFont();
        }

        private void FormatThree_CheckedChanged(object sender, EventArgs e)
        {
            format = FontStyle.Bold;
            UpdateFont();
        }
        private void FormatFour_CheckedChanged(object sender, EventArgs e)
        {
            format = FontStyle.Underline;
            UpdateFont();
        }
        // numeric update

        private void SizeNumeric_ValueChanged(object sender, EventArgs e)
        {

            size = (int)SizeNumeric.Value;
            UpdateFont();
        }
        private void TextEnter_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && (TextEnter.Text != null && TextEnter.Text != "") && TextEnter.Font != null)
            {
                ClipEntry entry = new ClipEntry(TextEnter.Text, TextEnter.Font);
                TextEnter.Text = "";
                TextEnter.Font = new Font("Times New Roman", 9, FontStyle.Regular);

                if (clipboard.Count >= 4) // if the clipboard is full, delete the oldest entry (basically a queue)
                {
                    clipboard.RemoveAt(0);
                }
                clipboard.Add(entry);
                
                ClipboardUpdate();
            }
        }
        private void ClipboardUpdate() // this code assigns the boxes to their values in the list, removes gaps when an object is removed, and fills blanks
        {
            for (int i = 0; i < 4; i++)
            {
                if (i < clipboard.Count) {
                    switch (i)
                    {
                        case 0:
                            ClipOne.Text = clipboard[i].GetText();
                            ClipOne.Font = clipboard[i].GetFont();
                            break;
                        case 1:
                            ClipTwo.Text = clipboard[i].GetText();
                            ClipTwo.Font = clipboard[i].GetFont();
                            break;
                        case 2:
                            ClipThree.Text = clipboard[i].GetText();
                            ClipThree.Font = clipboard[i].GetFont();
                            break;
                        case 3:
                            ClipFour.Text = clipboard[i].GetText();
                            ClipFour.Font = clipboard[i].GetFont();
                            break;
                    }
                }
                else
                {
                    switch (i)
                    {
                        case 0:
                            ClipOne.Text = "-";
                            ClipOne.Font = new Font("Agency FB", 9);
                            break;
                        case 1:
                            ClipTwo.Text = "-";
                            ClipTwo.Font = new Font("Agency FB", 9);
                            break;
                        case 2:
                            ClipThree.Text = "-";
                            ClipThree.Font = new Font("Agency FB", 9);
                            break;
                        case 3:
                            ClipFour.Text = "-";
                            ClipFour.Font = new Font("Agency FB", 9);
                            break;
                    }
                }
            }
        }
        private void SetTextBox(int index) // set the text box to which input is selected 
        {
            TextEnter.Text = clipboard[index].GetText();
            TextEnter.Font = clipboard[index].GetFont();
        }
        // click on clipboards

        private void ClipOne_Click(object sender, EventArgs e)
        {
            if (clipboard.Count >= 1)
            {
                SetTextBox(0);
                clipboard.RemoveAt(0);
                ClipboardUpdate();
            }
        }

        private void ClipTwo_Click(object sender, EventArgs e)
        {
            if (clipboard.Count >= 2)
            {
                SetTextBox(1);
                clipboard.RemoveAt(1);
                ClipboardUpdate();
            }
        }

        private void ClipThree_Click(object sender, EventArgs e)
        {
            if (clipboard.Count >= 3)
            {
                SetTextBox(2);
                clipboard.RemoveAt(2);
                ClipboardUpdate();
            }
        }

        private void ClipFour_Click(object sender, EventArgs e)
        {
            if (clipboard.Count >= 4)
            {
                SetTextBox(3);
                clipboard.RemoveAt(3);
                ClipboardUpdate();
            }
        }
    }
    public class ClipEntry // this object stores each entry in the clipboard's properties
    {
        private String text; // the text entered
        private Font clipFont; // the font, size, and format stored as the Font object

        public ClipEntry(string text, Font clipFont)
        {
            this.text = text;
            this.clipFont = clipFont;
        }
        // setters

        public void SetText(String t)
        {
            this.text = t;
        }
        public void SetFont(Font f)
        {
            this.clipFont = f;
        }
        // getters
        public string GetText()
        {
            return this.text;
        }
        public Font GetFont()
        {
            return this.clipFont;
        }
    }
}
