﻿namespace SecondProjectAssignmentNG
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TextEnter = new System.Windows.Forms.TextBox();
            this.FontGroup = new System.Windows.Forms.GroupBox();
            this.FontFour = new System.Windows.Forms.RadioButton();
            this.FontThree = new System.Windows.Forms.RadioButton();
            this.FontTwo = new System.Windows.Forms.RadioButton();
            this.FontOne = new System.Windows.Forms.RadioButton();
            this.SizeGroup = new System.Windows.Forms.GroupBox();
            this.SizeNumeric = new System.Windows.Forms.NumericUpDown();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ClipLabel = new System.Windows.Forms.Label();
            this.FormatBox = new System.Windows.Forms.GroupBox();
            this.FormatFour = new System.Windows.Forms.RadioButton();
            this.FormatThree = new System.Windows.Forms.RadioButton();
            this.FormatTwo = new System.Windows.Forms.RadioButton();
            this.FormatOne = new System.Windows.Forms.RadioButton();
            this.ClipOne = new System.Windows.Forms.Label();
            this.ClipTwo = new System.Windows.Forms.Label();
            this.ClipThree = new System.Windows.Forms.Label();
            this.ClipFour = new System.Windows.Forms.Label();
            this.FontGroup.SuspendLayout();
            this.SizeGroup.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SizeNumeric)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.FormatBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // TextEnter
            // 
            this.TextEnter.Location = new System.Drawing.Point(6, 20);
            this.TextEnter.Name = "TextEnter";
            this.TextEnter.Size = new System.Drawing.Size(557, 22);
            this.TextEnter.TabIndex = 1;
            this.TextEnter.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TextEnter_KeyDown);
            // 
            // FontGroup
            // 
            this.FontGroup.Controls.Add(this.FontFour);
            this.FontGroup.Controls.Add(this.FontThree);
            this.FontGroup.Controls.Add(this.FontTwo);
            this.FontGroup.Controls.Add(this.FontOne);
            this.FontGroup.Location = new System.Drawing.Point(12, 29);
            this.FontGroup.Name = "FontGroup";
            this.FontGroup.Size = new System.Drawing.Size(200, 145);
            this.FontGroup.TabIndex = 2;
            this.FontGroup.TabStop = false;
            this.FontGroup.Text = "Font Selection";
            // 
            // FontFour
            // 
            this.FontFour.AutoSize = true;
            this.FontFour.Font = new System.Drawing.Font("Algerian", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FontFour.Location = new System.Drawing.Point(6, 100);
            this.FontFour.Name = "FontFour";
            this.FontFour.Size = new System.Drawing.Size(92, 19);
            this.FontFour.TabIndex = 3;
            this.FontFour.Text = "Algerian";
            this.FontFour.UseVisualStyleBackColor = true;
            this.FontFour.CheckedChanged += new System.EventHandler(this.FontFour_CheckedChanged);
            // 
            // FontThree
            // 
            this.FontThree.AutoSize = true;
            this.FontThree.Font = new System.Drawing.Font("Jokerman", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FontThree.Location = new System.Drawing.Point(7, 74);
            this.FontThree.Name = "FontThree";
            this.FontThree.Size = new System.Drawing.Size(93, 24);
            this.FontThree.TabIndex = 2;
            this.FontThree.Text = "Jokerman";
            this.FontThree.UseVisualStyleBackColor = true;
            this.FontThree.CheckedChanged += new System.EventHandler(this.FontThree_CheckedChanged);
            // 
            // FontTwo
            // 
            this.FontTwo.AutoSize = true;
            this.FontTwo.Font = new System.Drawing.Font("Poor Richard", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FontTwo.Location = new System.Drawing.Point(7, 48);
            this.FontTwo.Name = "FontTwo";
            this.FontTwo.Size = new System.Drawing.Size(89, 20);
            this.FontTwo.TabIndex = 1;
            this.FontTwo.Text = "Poor Richard";
            this.FontTwo.UseVisualStyleBackColor = true;
            this.FontTwo.CheckedChanged += new System.EventHandler(this.FontTwo_CheckedChanged);
            // 
            // FontOne
            // 
            this.FontOne.AutoSize = true;
            this.FontOne.Checked = true;
            this.FontOne.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FontOne.Location = new System.Drawing.Point(7, 22);
            this.FontOne.Name = "FontOne";
            this.FontOne.Size = new System.Drawing.Size(127, 19);
            this.FontOne.TabIndex = 0;
            this.FontOne.TabStop = true;
            this.FontOne.Text = "Times New Roman";
            this.FontOne.UseVisualStyleBackColor = true;
            this.FontOne.CheckedChanged += new System.EventHandler(this.FontOne_CheckedChanged);
            // 
            // SizeGroup
            // 
            this.SizeGroup.Controls.Add(this.SizeNumeric);
            this.SizeGroup.Location = new System.Drawing.Point(12, 311);
            this.SizeGroup.Name = "SizeGroup";
            this.SizeGroup.Size = new System.Drawing.Size(200, 52);
            this.SizeGroup.TabIndex = 4;
            this.SizeGroup.TabStop = false;
            this.SizeGroup.Text = "Font Size";
            // 
            // SizeNumeric
            // 
            this.SizeNumeric.Location = new System.Drawing.Point(6, 22);
            this.SizeNumeric.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.SizeNumeric.Minimum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.SizeNumeric.Name = "SizeNumeric";
            this.SizeNumeric.Size = new System.Drawing.Size(120, 22);
            this.SizeNumeric.TabIndex = 0;
            this.SizeNumeric.Value = new decimal(new int[] {
            9,
            0,
            0,
            0});
            this.SizeNumeric.ValueChanged += new System.EventHandler(this.SizeNumeric_ValueChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ClipFour);
            this.groupBox1.Controls.Add(this.ClipThree);
            this.groupBox1.Controls.Add(this.ClipTwo);
            this.groupBox1.Controls.Add(this.ClipOne);
            this.groupBox1.Controls.Add(this.ClipLabel);
            this.groupBox1.Controls.Add(this.TextEnter);
            this.groupBox1.Location = new System.Drawing.Point(219, 29);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(569, 334);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Text";
            // 
            // ClipLabel
            // 
            this.ClipLabel.AutoSize = true;
            this.ClipLabel.Location = new System.Drawing.Point(6, 103);
            this.ClipLabel.Name = "ClipLabel";
            this.ClipLabel.Size = new System.Drawing.Size(66, 16);
            this.ClipLabel.TabIndex = 2;
            this.ClipLabel.Text = "Clipboard";
            // 
            // FormatBox
            // 
            this.FormatBox.Controls.Add(this.FormatFour);
            this.FormatBox.Controls.Add(this.FormatThree);
            this.FormatBox.Controls.Add(this.FormatTwo);
            this.FormatBox.Controls.Add(this.FormatOne);
            this.FormatBox.Location = new System.Drawing.Point(12, 180);
            this.FormatBox.Name = "FormatBox";
            this.FormatBox.Size = new System.Drawing.Size(200, 145);
            this.FormatBox.TabIndex = 4;
            this.FormatBox.TabStop = false;
            this.FormatBox.Text = "Font Format";
            // 
            // FormatFour
            // 
            this.FormatFour.AutoSize = true;
            this.FormatFour.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Underline);
            this.FormatFour.Location = new System.Drawing.Point(6, 100);
            this.FormatFour.Name = "FormatFour";
            this.FormatFour.Size = new System.Drawing.Size(86, 20);
            this.FormatFour.TabIndex = 3;
            this.FormatFour.Text = "Underline";
            this.FormatFour.UseVisualStyleBackColor = true;
            this.FormatFour.CheckedChanged += new System.EventHandler(this.FormatFour_CheckedChanged);
            // 
            // FormatThree
            // 
            this.FormatThree.AutoSize = true;
            this.FormatThree.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormatThree.Location = new System.Drawing.Point(7, 74);
            this.FormatThree.Name = "FormatThree";
            this.FormatThree.Size = new System.Drawing.Size(60, 20);
            this.FormatThree.TabIndex = 2;
            this.FormatThree.Text = "Bold";
            this.FormatThree.UseVisualStyleBackColor = true;
            this.FormatThree.CheckedChanged += new System.EventHandler(this.FormatThree_CheckedChanged);
            // 
            // FormatTwo
            // 
            this.FormatTwo.AutoSize = true;
            this.FormatTwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormatTwo.Location = new System.Drawing.Point(7, 48);
            this.FormatTwo.Name = "FormatTwo";
            this.FormatTwo.Size = new System.Drawing.Size(55, 20);
            this.FormatTwo.TabIndex = 1;
            this.FormatTwo.Text = "Italic";
            this.FormatTwo.UseVisualStyleBackColor = true;
            this.FormatTwo.CheckedChanged += new System.EventHandler(this.FormatTwo_CheckedChanged);
            // 
            // FormatOne
            // 
            this.FormatOne.AutoSize = true;
            this.FormatOne.Checked = true;
            this.FormatOne.Location = new System.Drawing.Point(7, 22);
            this.FormatOne.Name = "FormatOne";
            this.FormatOne.Size = new System.Drawing.Size(76, 20);
            this.FormatOne.TabIndex = 0;
            this.FormatOne.TabStop = true;
            this.FormatOne.Text = "Regular";
            this.FormatOne.UseVisualStyleBackColor = true;
            this.FormatOne.CheckedChanged += new System.EventHandler(this.FormatOne_CheckedChanged);
            // 
            // ClipOne
            // 
            this.ClipOne.AutoSize = true;
            this.ClipOne.Location = new System.Drawing.Point(5, 154);
            this.ClipOne.Name = "ClipOne";
            this.ClipOne.Size = new System.Drawing.Size(11, 16);
            this.ClipOne.TabIndex = 3;
            this.ClipOne.Text = "-";
            this.ClipOne.Click += new System.EventHandler(this.ClipOne_Click);
            // 
            // ClipTwo
            // 
            this.ClipTwo.AutoSize = true;
            this.ClipTwo.Location = new System.Drawing.Point(6, 204);
            this.ClipTwo.Name = "ClipTwo";
            this.ClipTwo.Size = new System.Drawing.Size(11, 16);
            this.ClipTwo.TabIndex = 4;
            this.ClipTwo.Text = "-";
            this.ClipTwo.Click += new System.EventHandler(this.ClipTwo_Click);
            // 
            // ClipThree
            // 
            this.ClipThree.AutoSize = true;
            this.ClipThree.Location = new System.Drawing.Point(6, 253);
            this.ClipThree.Name = "ClipThree";
            this.ClipThree.Size = new System.Drawing.Size(11, 16);
            this.ClipThree.TabIndex = 5;
            this.ClipThree.Text = "-";
            this.ClipThree.Click += new System.EventHandler(this.ClipThree_Click);
            // 
            // ClipFour
            // 
            this.ClipFour.AutoSize = true;
            this.ClipFour.Location = new System.Drawing.Point(6, 307);
            this.ClipFour.Name = "ClipFour";
            this.ClipFour.Size = new System.Drawing.Size(11, 16);
            this.ClipFour.TabIndex = 6;
            this.ClipFour.Text = "-";
            this.ClipFour.Click += new System.EventHandler(this.ClipFour_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.FormatBox);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.SizeGroup);
            this.Controls.Add(this.FontGroup);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FontGroup.ResumeLayout(false);
            this.FontGroup.PerformLayout();
            this.SizeGroup.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.SizeNumeric)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.FormatBox.ResumeLayout(false);
            this.FormatBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox TextEnter;
        private System.Windows.Forms.GroupBox FontGroup;
        private System.Windows.Forms.RadioButton FontOne;
        private System.Windows.Forms.RadioButton FontFour;
        private System.Windows.Forms.RadioButton FontThree;
        private System.Windows.Forms.RadioButton FontTwo;
        private System.Windows.Forms.GroupBox SizeGroup;
        private System.Windows.Forms.NumericUpDown SizeNumeric;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label ClipLabel;
        private System.Windows.Forms.GroupBox FormatBox;
        private System.Windows.Forms.RadioButton FormatFour;
        private System.Windows.Forms.RadioButton FormatThree;
        private System.Windows.Forms.RadioButton FormatTwo;
        private System.Windows.Forms.RadioButton FormatOne;
        private System.Windows.Forms.Label ClipThree;
        private System.Windows.Forms.Label ClipTwo;
        private System.Windows.Forms.Label ClipOne;
        private System.Windows.Forms.Label ClipFour;
    }
}

